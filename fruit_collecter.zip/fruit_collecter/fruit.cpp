#include "splashkit.h"
#include "fruit.h"
// The fruit bitmap function converts a fruit kind into a
// bitmap that can be used.
bitmap fruit_bitmap(fruit_kind kind)
{
    switch (kind)
    {
    case BOMB:
        return bitmap_named("bomb");
    case BANANA:
        return bitmap_named("banana");
    case STRAWBERRY:
        return bitmap_named("strawberry");
    case WATERMELON:
        return bitmap_named("watermelon");
    default:
        return bitmap_named("apple");
        }
}
fruit_data new_fruit(double x)
{
    fruit_data result;
    result.kind = static_cast<fruit_kind>(rnd(5));
    result.fruit_sprite = create_sprite(fruit_bitmap(result.kind));
    // intial position of fruit
    sprite_set_x(result.fruit_sprite, x);
    sprite_set_y(result.fruit_sprite, -2);
    // set the velocity along y direction
    sprite_set_dy(result.fruit_sprite, 4);
    return result;
}
void draw_fruit(const fruit_data &fruit)
{
    draw_sprite(fruit.fruit_sprite);
}
// This is used to update the fruit sprite
void update_fruit(fruit_data &fruit)
{
    update_sprite(fruit.fruit_sprite);
}