//
// SplashKit Generated Twitter C++ Code
// DO NOT MODIFY
//

#ifndef __twitter_h
#define __twitter_h

#include <string>
#include <vector>
using std::string;
using std::vector;


#endif /* __twitter_h */
