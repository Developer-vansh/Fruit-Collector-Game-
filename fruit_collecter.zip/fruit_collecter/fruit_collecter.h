#ifndef FRUIT_COLLLECTER
#define FRUIT_COLLECTER
#include <splashkit.h>
#include <vector>
#include "player.h"
#include "fruit.h"

using namespace std;

struct game_data
{
    player_data player;
    vector<fruit_data> fruit;
};

// to create and intialize the player for game
game_data new_game(int player_type);
// to update the all sprites in game on the basis of their movement
void update_game(game_data &game);
// to draw the game(player and fruits) sprite on screen
void draw_game(game_data &game);
// to add the fruits on screen
void add_fruit(game_data &game);
// to check the collision b/w fruit and player
void check_collision(game_data &game);
// to check fruit collide with the bottom of screen
void check_down(game_data &game);
// to apply the effect on fruit when it is collided with player
void apply_fruit(game_data &game, int index);
// to remove the fruit when it is collided
void remove_fruit(game_data &game, int index);
// to draw the head up display
void draw_hud(game_data &game);
#endif
