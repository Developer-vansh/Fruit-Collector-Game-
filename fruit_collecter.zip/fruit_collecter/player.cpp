#include <splashkit.h>
#include "player.h"
using namespace std;
bitmap player_bitmap(player_kind kind)
{
    switch (kind)
    {
    case BASKET:
        return bitmap_named("basket");
    case RABBIT:
        return bitmap_named("rabbit1");
    case GHOST:
        return bitmap_named("ghost");
    default:
        return bitmap_named("basket");
        }
}
int spritex = 400;
int spritey = 463;

// to initialize the new player
player_data new_player(int player_number)
{
    player_data result;
    result.score = 0;
    result.life = 20;
    result.kind=static_cast<player_kind>(player_number);
    bitmap default_bitmap = player_bitmap(result.kind);
    result.player_sprite = create_sprite(default_bitmap);
    sprite_set_x(result.player_sprite, spritex);
    sprite_set_y(result.player_sprite, spritey);
    return result;
}
// to draw the sprite of player on screen
void draw_player(const player_data &player_to_draw)
{
    draw_sprite(player_to_draw.player_sprite);
}
// to update the player
void update_player(player_data &player_to_update)
{
    update_sprite(player_to_update.player_sprite);
}
// to handle the input  from user for the movement of player
void handle_input(player_data &player)
{

    if (mouse_down(LEFT_BUTTON) || key_down(LEFT_KEY))
    {
        int leftmove = sprite_x(player.player_sprite) - player_MOVE_SPEED;
        if (leftmove > 0)
            sprite_set_x(player.player_sprite, leftmove);
    }

    if (mouse_down(RIGHT_BUTTON) || key_down(RIGHT_KEY))
    {
        int rightmove = sprite_x(player.player_sprite) + player_MOVE_SPEED;
        if (rightmove < 800)
            sprite_set_x(player.player_sprite, rightmove);
    }
}