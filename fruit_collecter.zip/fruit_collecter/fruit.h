#ifndef FRUIT_COLLECTER_FRUITS
#define FRUIT_COLLECTER_FRUITS
#include "splashkit.h"
using namespace std;
// this is for the selection of different fruit kinds
enum fruit_kind
{
    BOMB,
    APPLE,
    BANANA,
    STRAWBERRY,
    WATERMELON
};

struct fruit_data
{
    sprite fruit_sprite;
    fruit_kind kind;
};

fruit_data new_fruit(double x);
void draw_fruit(const fruit_data &fruit);
void update_fruit(fruit_data &fruit);
#endif