#ifndef PLAYER
#define PLAYER

#include <splashkit.h>
#include <vector>
using namespace std;
#define player_MOVE_SPEED 15

enum player_kind
{
    BASKET=1,
    RABBIT,
    GHOST
};
/**
 * The player data keeps track of all of the information related to the player.
 *
 * @field   player_sprite   The player sprite - used to track position and movement
 * @field   score           The current score for the player
 * @field   life            life of player
 */
struct player_data
{
    sprite player_sprite;
    player_kind kind;
    int score;
    double life;
};

player_data new_player(int player_number);
void draw_player(const player_data &player_to_draw);
void update_player(player_data &player_to_update);
void handle_input(player_data &player);

#endif