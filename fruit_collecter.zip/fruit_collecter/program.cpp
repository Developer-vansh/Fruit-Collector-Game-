#include "splashkit.h"
#include "fruit_collecter.h"
using namespace std;
// to load the resources
void load_resources()
{
    load_resource_bundle("bundle_game", "fruit_collecter.txt");
    load_bitmap("start", "start.jpeg");
    load_bitmap("back", "background.jpg");
    load_bitmap("level", "level.jpeg");
    load_bitmap("lvl", "level.png");
    load_bitmap("back2", "background2.jpg");
    load_bitmap("back3", "back3.png");
    load_font("font1", "fast99.ttf");
    load_bitmap("empty", "empty.png");
    load_bitmap("lifebar", "red_bar.png");
    load_sound_effect("theme", "theme1.mp3");
    play_sound_effect("theme");
}
void game_over()
{
    clear_screen(COLOR_BLUE_VIOLET);
    draw_text(" GAME OVER", COLOR_LIGHT_YELLOW, "font1", 100, 125, 250);
    refresh_screen(60);
    delay(3000);
}
void level1(game_data &game)
{

    while (not quit_requested())
    {
        // Handle input to adjust player movement
        process_events();
        handle_input(game.player);
        // update the player and fruits
        update_game(game);

        draw_bitmap("back", 0, 0);
        // draw the player and fruits
        draw_game(game);
        if (game.player.score >= 20)
        {
            return;
        }
        // close the window if life of player become zero
        if (game.player.life == 0)
        {   game_over();
            close_window("FRUIT COLLECTER");
        }
        refresh_screen(60);
    }

    return;
}
void level_up(game_data &level)
{
    while (not quit_requested())
    {
        process_events();
        if (key_down(SPACE_KEY))
        {
            return;
        }
        draw_bitmap("lvl", 0, 0);
        draw_text(" SCORE:" + to_string(level.player.score), COLOR_BLACK, "font1", 80, 293, 272);
        refresh_screen(60);
    }
    return;
}
void level2(game_data &game)
{

    while (not quit_requested())
    {
        // Handle input to adjust player movement
        process_events();
        handle_input(game.player);
        // update the player and fruits
        update_game(game);

        draw_bitmap("back2", 0, 0);
        // draw the player and fruits
        draw_game(game);
        if (game.player.score >= 30)
        {
            return;
        }
        // close the window if life of player become zero
        if (game.player.life == 0)
        {   game_over();
            close_window("FRUIT COLLECTER");
        }
        refresh_screen(60);
    }
}
void level3(game_data &game)
{

    while (not quit_requested())
    {
        // Handle input to adjust player movement
        process_events();
        handle_input(game.player);
        // update the player and fruits
        update_game(game);

        draw_bitmap("back3", 0, 0);
        // draw the player and fruits
        draw_game(game);
        // close the window if life of player become zero
        if (game.player.life == 0)
        {   game_over();
            close_window("FRUIT COLLECTER");
        }
        refresh_screen(60);
    }
}

int main()
{
    open_window("FRUIT COLLECTER", 950, 600);
    load_resources();
    draw_bitmap("start", 0, 0);
    refresh_screen(60);
    delay(5000);
    // level1
    game_data lvl1 = new_game(1);
    level1(lvl1);
    level_up(lvl1);
    // level2
    game_data lvl2 = new_game(2);
    level2(lvl2);
    level_up(lvl2);
    // level3
    game_data lvl3 = new_game(3);
    level3(lvl3);
    return 0;
}