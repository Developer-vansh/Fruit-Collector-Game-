#include "splashkit.h"
using namespace std;
#include "fruit_collecter.h"
#include <vector>

game_data new_game(int player_type)
{
    game_data game;
    game.player = new_player(player_type);
    return game;
}
void update_game(game_data &game)
{
    if (rnd() < 0.03)
    {
        add_fruit(game);
    }
    check_collision(game);
    check_down(game);
    // to update fruits
    for (int i = 0; i < game.fruit.size(); i++)
    {
        update_fruit(game.fruit[i]);
    }

    // to update player
    update_player(game.player);
}
void draw_game(game_data &game)
{
    draw_hud(game);
    // to draw the player
    draw_player(game.player);
    // to draw the sprite of all fruits on screen
    for (int i = 0; i < game.fruit.size(); i++)
    {
        draw_fruit(game.fruit[i]);
    }
}
void add_fruit(game_data &game)
{
    game.fruit.push_back(new_fruit(rnd(50, 750)));
}
void check_collision(game_data &game)
{ 
    for (int i = 0; i < game.fruit.size(); i++)
    {
        // if player collide with fruit then collect it and apply the effect
         if (sprite_collision(game.player.player_sprite, game.fruit[i].fruit_sprite))
        {
            if(game.fruit[i].kind==BOMB){
                load_sound_effect("game","bomb.wav");
                play_sound_effect("game");
              if(game.player.score>=2){
                game.player.score-=2;
              }
            }
            else{
            apply_fruit(game, i);
            }
            remove_fruit(game, i);
    }
}
}
void check_down(game_data &game)
{
    for (int i = 0; i < game.fruit.size(); i++)
    {
        point_2d position = sprite_position(game.fruit[i].fruit_sprite);
        if (position.y > 500)
        {
            remove_fruit(game, i);
          
            if(game.fruit[i].kind!=BOMB){
                  game.player.life -= 1;
                  load_sound_effect("down", "new.wav");
                  play_sound_effect("down");
            }
        }
    }
}
void apply_fruit(game_data &game, int index)
{
    
    load_sound_effect("collect", "collect.mp3");
    play_sound_effect("collect");
    game.player.score++;
   
}
void remove_fruit(game_data &game, int index)
{
    game.fruit[index] = game.fruit[game.fruit.size() - 1];
    game.fruit.pop_back();
}
void draw_hud(game_data &game)
{
    fill_rectangle(COLOR_BURLY_WOOD, 0, 0, 150, 50);
    draw_bitmap("heart", 3, 5);
    draw_bitmap("empty", 23, 7);
    draw_bitmap("lifebar", 23, 6.5, option_part_bmp(0, 0, bitmap_width("empty") * (game.player.life / 20), bitmap_height("empty")));
    draw_text("SCORE : " + to_string(game.player.score), COLOR_BLACK, "font1", 20, 3, 30);
}